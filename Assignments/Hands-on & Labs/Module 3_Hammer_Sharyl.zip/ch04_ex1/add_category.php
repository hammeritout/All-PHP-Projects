<?php
// Get the category data
//$category_id = filter_input(INPUT_POST, 'category_id', FILTER_VALIDATE_INT);
$name = filter_input(INPUT_POST, 'name');


// Validate inputs
//if ($category_id == null || $category_id == false || $name == null)
if ($name == null)  {
    $error = "Invalid category data. Check all fields and try again.";
	
    include('error.php');
} else {
    require_once('database.php');

    // Add the category to the database  
    $query = 'INSERT INTO categories
                 (categoryName)
              VALUES
                 (:name)';
    $statement = $db->prepare($query);
  //  $statement->bindValue(':category_id', $category_id);
    $statement->bindValue(':name', $name);
    $statement->execute();
    $statement->closeCursor();

    // Display the Category List page
    include('category_list.php');
}
?>